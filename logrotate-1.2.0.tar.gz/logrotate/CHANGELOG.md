## v1.2.0:

* [COOK-2401] - Add the ability to manage the global logrotate
  configuration

## v1.1.0:

* [COOK-2218] - Logrotate size parameter

## v1.0.2:

* [COOK-1027] - Add support for pre-/post-rotate commands
* [COOK-1338] - Update log rotate for more flexibility of rotate options
* [COOK-1598] - "Create" isn't a mandatory option
